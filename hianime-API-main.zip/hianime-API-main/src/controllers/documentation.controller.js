import apiDocumentation from '../utils/documentation.js';

const documentationController = async () => {
  return apiDocumentation;
};

export default documentationController;
